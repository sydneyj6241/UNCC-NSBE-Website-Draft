$(document).ready(function() {
    /*Code for Accordion*/
$("#accordion").accordion({
    active: false,
    collapsible: true
  });
  /*End of code for Accordion*/
});